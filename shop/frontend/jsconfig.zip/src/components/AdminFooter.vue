<template>
    <footer>
      <p>Admin Footer</p>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'AdminFooter'
  }
  </script>
  
  <style scoped>
  /* 관리자 푸터 스타일 */
  </style>
  