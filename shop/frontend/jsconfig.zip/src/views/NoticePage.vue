<template>
    <div class="hello">
      <h1>공지사항페이지{{ }}</h1>
      
    </div>
  </template>