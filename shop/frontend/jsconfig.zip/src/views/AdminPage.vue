<template>
    <div class="hello">
      <h1>환영합니다!</h1>
      
    </div>

    <div></div>
</template>
<script>
    export default{
    data(){
    return {};
    },
    created () {},
    methods :{}
        }
</script>
<style></style>
