<template>
    <div class="hello">
      <h1>Q&A페이지</h1>
      
    </div>
  </template>