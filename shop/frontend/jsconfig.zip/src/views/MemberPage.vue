<template>
    <div class="hello">
      <h1>회원페이지{{ }}</h1>
      
    </div>
  </template>