<template>
  <div class="container">
    <div class="text-start fs-1">주문/결제</div>
    <div class="text-start fs-4">주문상품</div>
    <table class="table">
      <colgroup>
        <col width="*">
        <col width="*">
        <col width="200">
        <col width="200">
      </colgroup>
      <thead>
        <tr>
          <th colspan="2">상품</th>
          <th>수량</th>
          <th>가격</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>이미지</td>
          <td>상품명</td>
          <td>0개</td>
          <td>00,000원</td>
        </tr>
      </tbody>
    </table>
    <div class="text-start fs-4">배송지 정보</div>
  </div>
</template>
<script>
  export default {
    data() {
      return {};
    },
    created() {},
    methods: {},
  }
</script>
<style>
  
</style>